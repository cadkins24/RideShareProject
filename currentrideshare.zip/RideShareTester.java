import java.util.ArrayList;

public class RideShareTester {
    public static void main(String[] args) {
        //Creating a road
        Road r = new Road();
        
        System.out.println("Establishing 3 stations...");
        Station stat1 = new Station();
        r.addStation(stat1);
        Station stat2 = new Station();
        r.addStation(stat2);
        Station stat3 = new Station();
        r.addStation(stat3);
    
        System.out.println("Generating non-random cars with locations and destination...");
        Car car1 = new Car(1, 3);
        r.addCar(car1);
        Car car2 = new Car(2, 1);
        r.addCar(car2);

        System.out.println("Generating non-random passengers with locations and destinations...");
        Passenger lilie = new Passenger(1, 3);
        Passenger claire = new Passenger(2, 3);
        Passenger bob = new Passenger(2, 1);
        r.addPassenger(lilie);
        r.addPassenger(claire);
        r.addPassenger(bob);
        r.printInfo();
        System.out.println();
        
        //loop that moves cars a certain number of times
        for(int i = 0; i < 3; i++) {
            r.moveAllCars();
            r.printInfo();
            System.out.println();
        }

        //calculate total revenue
        System.out.println("Calculating total revenue generated...");
        System.out.println("Passenger Miles/Miles Driven: " + r.calculateRevenue() + " / " + r.calculateMiles());
        System.out.println("Average revenue: " + (r.calculateRevenue() / r.calculateMiles()));
    }

    //do i need to write out method headers/ explantions for each one?
    //how to fix index out of bounds error on moveAllCars()
}
